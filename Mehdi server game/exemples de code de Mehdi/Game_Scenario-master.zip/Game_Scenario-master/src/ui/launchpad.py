from game.page import Page
from game.ui.block import Block
from game.ui.action import ActionButton
from game.ui.content import ContentRow, ContentActionRow
from game.ui.row import RowStaticText, RowDynamicText, RowChecklist, RowPasscode, RowButton, RowSlider

from game.ui.launchpad import Launchpad

class LaunchpadPage(Page):
    def __init__(self, scenario):
        self.scenario = scenario
        self.logic = self.scenario.logic
        Page.__init__(self,
            phase = "Jeu",
            name = "Launchpad",

            ui = [ 
                self.scenario.unity.get_ui(),
                self.scenario.UI.get_ui()
            ],
        ),




