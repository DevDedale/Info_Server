from game.ui.block import Block
from game.ui.row import RowStaticText, RowDynamicText, RowButton, RowLedBar, RowSlider, RowPushButton, RowDialogInput, RowSlider, RowJsonEditor
from game.ui.content import ContentRow, ContentActionRow


class UnityGame:
    def __init__(self, scenario):
        self.logic = scenario.logic

        self.siossequence = self.logic.devices.sios('Fairy').state('sequence')
        self.siosfeedback = self.logic.devices.sios('Fairy').state('feedback')


    def get_ui(self):
        return Block(
                title="Fees",
                content = [
                    ContentRow([
                        RowDynamicText(self.siosfeedback)
                    ]),
                    ContentRow([
                        RowButton('remise a zero', click=self.siossequence.setter(0)),
                        RowButton('arrivee des fees', click=self.siossequence.setter(1)),
                        RowButton('merci pour 1 ou 2', click=self.siossequence.setter(2)),
                        RowButton('merci pour toutes', click=self.siossequence.setter(3)),
                        RowButton('1 min avant fin', click=self.siossequence.setter(4)),
                        RowDynamicText(self.siossequence)
                     ])
                ],
            )

       
