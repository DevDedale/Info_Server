




class SoundMgr :

  def __init__(self, logic) :
    self.unison = logic.devices.unison()
    self.configure_unison()    
    
    self.taverneEnceinte0 = self.unison.zone('0')
    
    self.sourceFip = self.taverneEnceinte0.source('fip')
    self.StopYourCry()
    
    
    
  def CryBaby(self) :
    self.sourceFip.url.set('http://icecast.radiofrance.fr/fip-midfi.mp3')
    self.sourceFip.play.set(True)
    
  
  def StopYourCry(self) :
    self.sourceFip.play.set(False)
    #pour remettre au d�but renvoyer l'URL
    
    
    
    
  def configure_unison(self):
    host = 'localhost'
    # this array contains all unison peers.
    # as they manage 1 stereo channel each
    # there are only 4 for the 8 soundboard channels
    portmapping = [
        '%s:9000'%host,
        '%s:9002'%host,
        '%s:9004'%host,
        '%s:9006'%host,
    ]

    # this is used to separate stereo channels
    # to 2 mono channels
    channelmapping = [
            'LR>L',
            'LR>R',
            ]


    allpeers = []

    # for each peer
    for i, pmap in enumerate(portmapping):
        # get its address and port
        address,port = pmap.split(':')

        # create a mono zone with its right channel
        peer = {
                'address': address,
                'port': '%s'%port,
                'mapping': channelmapping[0],
                'codec': 'none', 
            }

        self.unison.zone('%s'%(i*2)).configure(2,[
            peer
        ])
        allpeers.append(peer)

        # create a mono zone with its left channel
        peer = {
                'address': address,
                'port': '%s'%port,
                'mapping': channelmapping[1],
                'codec': 'opus', 
            }

        self.unison.zone('%s'%(i*2+1)).configure(2,[
            peer
                    ])
        allpeers.append(peer)



    #self.unison.zone('all').configure(2, allpeers)

    