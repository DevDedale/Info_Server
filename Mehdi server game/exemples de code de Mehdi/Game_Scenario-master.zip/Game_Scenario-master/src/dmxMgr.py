
from game.logic import GameLogic
import time


class DmxMgr :

  def __init__(self) :
    self.dmx = GameLogic().devices.dmx('soundboard')
    self.dmx.frame(10).set(255)

    for i in range(0, 511):
        #time.sleep(0.01)
        self.dmx.frame(i).set(0)
 


    for i in range(30, 511):
            self.dmx.frame(i).set(255)
            #time.sleep(0.5)
      
  
  
  
  def DanceFloor(self) :
    self.dmx.frame(10).set(0)
    self.dmx.frame(11).set(0)
    self.dmx.frame(12).set(0)
    self.dmx.frame(13).set(0)
    
    #self.dmx.frame(10).animation(mode="sin", min = 200, max = 255, period = 120, cycles = 0)
    #self.dmx.frame(11).animation(mode="rand", min = 0, max = 64, period = 10, cycles = 0)
    #self.dmx.frame(12).animation(mode="sin", min = 0, max = 255, period = 50, cycles = 0)
    #self.AnimTest()
    
    #liste des anims
    #pwm, tri, ramp, sin, random
    
  def EpateOlivier(self) :
    self.dmx.frame(12).set(200)
   
  
  def AnimTest(self) :
    def _anim(eventAskToQuit) :
      while(not eventAskToQuit.is_set()) :
        self.dmx.frame(10).set(0)
        time.sleep(0.5)
        self.dmx.frame(10).set(255)
        time.sleep(0.5)
        self.dmx.frame(10).set(64)
        time.sleep(0.5)
         
    GameLogic().scheduler.now(_anim)
        
 
