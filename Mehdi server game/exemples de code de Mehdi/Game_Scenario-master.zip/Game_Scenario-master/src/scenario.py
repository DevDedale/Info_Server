

from game.page import Page
from game.scenario import Scenario
from game.camera import Camera
from game.launchpad.launchpad import LaunchpadController
from game.launchpad.plugins import UnisonLaunchpadPlugin, DMXLaunchpadPlugin, TriggerLaunchpadPlugin

import game.ui.html as html

import os
import time, math, random

import random

from ui.launchpad import LaunchpadPage

from unity import UnityGame

from rooms.roomTest.hardware import HardwareTest
from rooms.roomTest.game import GameTest
from rooms.roomTest.ui import UITest
from dmxMgr import DmxMgr
from soundMgr import SoundMgr

class LaunchpadScenario(Scenario):
    NAME = "Launchpad"
    DESCRIPTION = "Launchpad testing grounds"
    AUTOLOAD = True
    REALM = "dedale"

    MIRSRVRIP= 'demo.magichanism.com'

    THEME_MAIN_COLOR = "#444"
    THEME_APP_BAR_BACKGROUND_SRC = "/soundboard-bar.png"
    THEME_APP_BAR_IMAGE_SRC = "/soundboard-bar-logo.png"
    THEME_NAVIGATION_DRAWER_IMAGE_SRC = "/soundboard-drawer.png"

    PATH = os.path.dirname(os.path.realpath(__file__))

    def initialize(self):
        self.logic.scheduler.every(30, self.step)
        self.unity = UnityGame(self)


#        self.groom = self.logic.devices.magigroom('groom-4827e2674dd7')


#        def cb(value):
#            self.groom.outputbay(0).gpio(0).set(value)


#        self.groom.inputbay(3).gpio(0).on_change(cb)


        self.hardwareTest = HardwareTest()
        self.gameTest = GameTest(self.hardwareTest, self)
        self.UI = UITest(self.gameTest)
        self.dmxMgr = DmxMgr()
        self.soundMgr = SoundMgr(self.logic)
        
        self.dmxMgr.DanceFloor()
        #self.soundMgr.CryBaby()

 

        #self.dmx = self.logic.devices.dmx('soundboard')

        #self.dmx.frame(10).set(255)
        #self.dmx.frame(11).set(255)
        #self.dmx.frame(12).set(255)
        #self.dmx.frame(13).set(255)
        #self.dmx.frame(14).set(255)
        #self.dmx.frame(15).set(255)








    def step(self,_):
        pass


    def deinitialize(self):
        pass

    def get_cameras(self):
        def mir_url(name, q=""):
            return "wss://{}/mir/streams/{}{}".format(
                self.MIRSRVRIP, name, q
                )
        cameras = []
#        for i in [
#                    'budapest',
#                    'reportage',
#                    'capital',
#                ]:
        for i in []:
            cameras.append(
                Camera(
                    i, i,
                    mir_url(i, ""), 4/3,
                    mir_url(i, ""), 16/9,
                    #unison_mon_url, monitor,
                    #unison_mic_url, micro,
                    #positions, _on_camera_position(ip),
                    #on_message_callback=message
                ))

        return cameras

    def get_ui(self): 
        return [
            LaunchpadPage(self),
        ]
