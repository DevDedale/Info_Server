from game.logic import GameLogic


class GameTest :

  def __init__ (self, hardware, scenario) :
    
    self.scenario = scenario
    self.hardware = hardware
    
    self.logic = self.hardware.logic
    self.siossequence = self.logic.devices.sios('Fairy').state('sequence')
 
    
    self.siossequence.set(0)    
    
#    def OnButtonPorte1(value) :
#      self.hardware.ventouse1.set(value)
    


    self.hardware.buttonPorte1.on_change(self.OnButtonPorte1bis, call_immediately = False)
    self.ResetDoor()




  def OnButtonPorte1bis(self, value) :
    if(not value) :
      self.OnSuccess()
    else :
      self.scenario.dmxMgr.EpateOlivier()
      self.scenario.soundMgr.CryBaby()
      self.siossequence.set(1)
    
  
  def OnSuccess(self) :
    self.hardware.ventouse1.set(False)
     
     
  def ResetDoor(self) :
    self.hardware.ventouse1.set(True)
    
    