from game.logic import GameLogic
from game.ui.block import Block
from game.ui.row import RowStaticText, RowDynamicText, RowButton, RowLedBar, RowSlider, RowPushButton, RowDialogInput, RowSlider, RowJsonEditor
from game.ui.content import ContentRow, ContentActionRow


class UITest :

  def __init__ (self, game) :
    

    self.game = game
    


  def get_ui(self):
        return Block(
                title="Fees",
                content = [
                    ContentRow([
                        RowButton('open the door', click=self.game.hardware.ventouse1.setter(False)),
                        RowButton('force the game', click=self.game.OnSuccess),
                        RowButton('reset the door', click=self.game.ResetDoor),
                        
                     ])
                ],
            )