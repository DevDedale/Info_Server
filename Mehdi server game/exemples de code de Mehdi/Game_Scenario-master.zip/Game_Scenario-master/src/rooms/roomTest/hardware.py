
from game.logic import GameLogic


class HardwareTest :

  def __init__ (self) :
    
    self.logic = GameLogic()
    
    self.groom = self.logic.devices.magigroom('groom-4827e2674dd7')
    
    
    self.buttonPorte1 = self.groom.inputbay(3).gpio(0)
    self.ventouse1 = self.groom.outputbay(0).gpio(0)
    
    